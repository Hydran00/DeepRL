from env.env import VisualGroundingEnv
# gym.envs.register(
#      id='VisualGrounding-v0',
#      entry_point='env.env:MyEnv'
# )

